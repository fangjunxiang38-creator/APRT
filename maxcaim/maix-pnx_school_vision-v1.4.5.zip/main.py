from maix import camera, image, app, uart, pinmap, err
from maix import time as maix_time
import cv2
import numpy as np
import math
import time

from vision_frame import ImuReceiver, encode

# ================= 1. 硬件初始化（不再需要 display） =================
img_w, img_h = 320, 240
cam = camera.Camera(img_w, img_h)
cam.skip_frames(30) 

# 串口初始化
err.check_raise(pinmap.set_pin_function("A19", "UART1_TX"), "set A19 TX")
err.check_raise(pinmap.set_pin_function("A18", "UART1_RX"), "set A18 RX")
serial = uart.UART("/dev/ttyS1", 115200)
sequence = 0
imu_receiver = ImuReceiver()


def on_imu_received(_serial, data):
    imu_receiver.feed(data, maix_time.ticks_ms())


# ================= 2. 核心参数 =================
REAL_WIDTH_MM = 80.0     
FOCAL_LENGTH = 425.0     

lost_frame_count = 0
last_target_rect = [0.0, 0.0, 0.0, 0.0] 
is_tracking = False

print("纯串口极速版启动！无图像显示，性能拉满。")

# ================= 3. 主循环 =================
try:
    serial.set_received_callback(on_imu_received)
    while not app.need_exit():
        img = cam.read()
        # 只做格式转换，不做显示
        frame = image.image2cv(img, ensure_bgr=True, copy=False) 
    
        gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
    
        # 顶帽操作过滤大面积背景
        kernel = cv2.getStructuringElement(cv2.MORPH_RECT, (40, 40))
        tophat = cv2.morphologyEx(gray, cv2.MORPH_TOPHAT, kernel)
        _, mask = cv2.threshold(tophat, 50, 255, cv2.THRESH_BINARY)

        contours, _ = cv2.findContours(mask, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)

        valid_rects = []
        for c in contours:
            area = cv2.contourArea(c)
            if 20 < area < 3000: 
                rect = cv2.minAreaRect(c)
                (cx, cy), (w, h), angle = rect
                if min(w, h) > 2.0:
                    ratio = max(w, h) / min(w, h)
                    if 0.3 < ratio < 3.0:
                        valid_rects.append((cx, cy, w, h))

        found_in_this_frame = False
        current_rect = [0.0, 0.0, 0.0, 0.0]
    
        if len(valid_rects) >= 2: 
            min_x = min(r[0] - r[2]/2 for r in valid_rects)
            max_x = max(r[0] + r[2]/2 for r in valid_rects)
            min_y = min(r[1] - r[3]/2 for r in valid_rects)
            max_y = max(r[1] + r[3]/2 for r in valid_rects)
        
            center_x = (min_x + max_x) / 2.0
            center_y = (min_y + max_y) / 2.0
            total_w = max_x - min_x
            total_h = max_y - min_y
        
            if 15 < total_w < 200 and 15 < total_h < 200:
                total_ratio = max(total_w, total_h) / min(total_w, total_h)
                if 0.5 < total_ratio < 2.0:
                    current_rect = [center_x, center_y, total_w, total_h]
                    found_in_this_frame = True

        # --- 追踪平滑 ---
        if found_in_this_frame:
            lost_frame_count = 0
            if not is_tracking:
                last_target_rect = current_rect
                is_tracking = True
            else:
                last_target_rect[0] = last_target_rect[0] * 0.7 + current_rect[0] * 0.3
                last_target_rect[1] = last_target_rect[1] * 0.7 + current_rect[1] * 0.3
                last_target_rect[2] = last_target_rect[2] * 0.7 + current_rect[2] * 0.3
                last_target_rect[3] = last_target_rect[3] * 0.7 + current_rect[3] * 0.3
        else:
            lost_frame_count += 1
            if lost_frame_count > 5:
                is_tracking = False

        # ================= 4. 计算物理距离、角度并发送 =================
        if is_tracking:
            cx, cy, w, h = last_target_rect
        
            # 1. 计算深度 Z
            pixel_width = (w + h) / 2.0
            distance_z_mm = (REAL_WIDTH_MM * FOCAL_LENGTH) / pixel_width
            distance_z_cm = distance_z_mm / 10.0
        
            # 2. 计算横向偏差 X
            pixel_offset_x = cx - (img_w / 2.0)
            offset_x_cm = (pixel_offset_x * distance_z_mm / FOCAL_LENGTH) / 10.0
        
            # 3. 计算偏转角度 Theta
            # math.atan2(y, x) 这里我们传 offset_x_cm 作为对边，distance_z_cm 作为邻边
            theta_rad = math.atan2(offset_x_cm, distance_z_cm)
        
            # 沿用当前 X、Z、Theta 的计算，按电控接口传米和弧度。
            ex_m = offset_x_cm / 100.0
            ey_m = distance_z_cm / 100.0
            eyaw_rad = theta_rad
        
            try:
                packet = encode(sequence, ex_m=ex_m, ey_m=ey_m, eyaw_rad=eyaw_rad)
            except ValueError:
                packet = encode(sequence, valid=False)
        
            print(f"X:{offset_x_cm:.1f}cm Z:{distance_z_cm:.1f}cm 弧度:{theta_rad:.1f}")
        
        else:
            packet = encode(sequence, valid=False)

        sent = 0
        while sent < len(packet):
            written = serial.write(packet[sent:])
            if written <= 0:
                raise RuntimeError(f"UART1 write failed ({written})")
            sent += written
        sequence = (sequence + 1) & 0xFFFF
        
        # 稍微给一点延时，防止 CPU 100% 占用导致系统卡死
        time.sleep(0.01)
finally:
    serial.close()
