"""Encode C-board control-error and camera-position frames; no hardware dependency."""
import struct
from math import isfinite, sqrt
from threading import Lock


def crc16(data):
    crc = 0xFFFF
    for byte in data:
        crc ^= byte
        for _ in range(8):
            crc = (crc >> 1) ^ (0x8408 if crc & 1 else 0)
    return crc


def encode(sequence, ex_m=0.0, ey_m=0.0, eyaw_rad=0.0, valid=True, ore_present=None):
    if not (-3 <= ex_m <= 3 and -3 <= ey_m <= 3 and -3.142 <= eyaw_rad <= 3.142):
        raise ValueError("Vision error exceeds reference protocol range")
    flags = int(bool(valid))
    if ore_present is not None:
        flags |= 2
        if ore_present:
            flags |= 4
    packet = struct.pack("<BBBBHBBhhh", 0xA5, 0x5A, 1, 1, sequence & 0xFFFF,
                         flags, 0, round(ex_m * 1000), round(ey_m * 1000),
                         round(eyaw_rad * 1000))
    return packet + struct.pack("<H", crc16(packet))


def encode_position(sequence, x_cm=0.0, y_cm=0.0, z_cm=0.0, valid=True):
    """Pack camera coordinates in cm: x right, y down, z forward; frame type 2."""
    if not (-300 <= x_cm <= 300 and -300 <= y_cm <= 300 and 0 <= z_cm <= 300):
        raise ValueError("Camera position exceeds protocol range")
    x_mm, y_mm, z_mm = round(x_cm * 10), round(y_cm * 10), round(z_cm * 10)
    if valid and z_mm == 0:
        raise ValueError("A valid camera position needs positive depth")
    packet = struct.pack("<BBBBHBBhhh", 0xA5, 0x5A, 1, 2, sequence & 0xFFFF,
                         int(bool(valid)), 0, x_mm, y_mm, z_mm)
    return packet + struct.pack("<H", crc16(packet))

def encode_xza(sequence, x_mm=0, z_mm=0, theta_tenths_rad=0, valid=True):
    """Type 4 payload: signed X and Z in mm, signed angle in tenths of a radian."""
    if valid and not (-3000 <= x_mm <= 3000 and 0 < z_mm <= 3000
                      and -15 <= theta_tenths_rad <= 15):
        raise ValueError("XZA outside the supported range")
    if not valid:
        x_mm = z_mm = theta_tenths_rad = 0
    packet = struct.pack("<BBBBHBBhhh", 0xA5, 0x5A, 1, 4, sequence & 0xFFFF,
                         int(bool(valid)), 0, x_mm, z_mm, theta_tenths_rad)
    return packet + struct.pack("<H", crc16(packet))


# 类型 3：C 板回传的 30 字节姿态包。所有多字节字段为小端。
# A5 5A 01 03 | seq:u16 | valid:u8 | reserved:u8 | sample_ms:u32 |
# qw:f32 qx:f32 qy:f32 qz:f32 | CRC16:u16
# sample_ms 属于 C 板时钟。received_ms 属于相机时钟，供接收超时判断使用。
class ImuReceiver:
    HEADER = b"\xA5\x5A\x01\x03"
    FRAME_SIZE = 30
    FRAME_TIMEOUT_MS = 50

    def __init__(self, timeout_ms=100):
        self.timeout_ms = timeout_ms
        # 只有串口接收回调修改组帧缓冲和序号记录。
        self._buffer = bytearray()
        self._arrival_ms = []
        self._last_sequence = None
        self._last_valid_ms = 0
        # 回调一次性替换快照，图像线程通过 latest() 取得副本。
        self._lock = Lock()
        self._latest = None

    def feed(self, data, received_ms):
        self._buffer.extend(data)
        self._arrival_ms.extend([received_ms] * len(data))
        while True:
            first = self._buffer.find(self.HEADER)
            if first < 0:
                # 最多保留帧头长度减一，支持帧头跨回调。
                del self._buffer[:-3]
                del self._arrival_ms[:-3]
                return
            if first:
                del self._buffer[:first]
                del self._arrival_ms[:first]
            if len(self._buffer) < self.FRAME_SIZE:
                return

            frame = self._buffer[:self.FRAME_SIZE]
            expected = struct.unpack_from("<H", frame, 28)[0]
            if (frame[6] not in (0, 1) or frame[7] != 0
                    or crc16(frame[:28]) != expected):
                del self._buffer[0]
                del self._arrival_ms[0]
                continue

            started_ms = self._arrival_ms[0]
            del self._buffer[:self.FRAME_SIZE]
            del self._arrival_ms[:self.FRAME_SIZE]
            if not 0 <= received_ms - started_ms <= self.FRAME_TIMEOUT_MS:
                continue

            q = struct.unpack_from("<4f", frame, 12)
            norm_squared = sum(value * value for value in q)
            if (frame[6] == 0 or not all(isfinite(value) for value in q)
                    or not 0.98 <= norm_squared <= 1.02):
                with self._lock:
                    self._latest = None
                continue

            sequence = struct.unpack_from("<H", frame, 4)[0]
            if (self._last_sequence is not None
                    and received_ms - self._last_valid_ms <= self.timeout_ms):
                advance = (sequence - self._last_sequence) & 0xFFFF
                if advance == 0 or advance >= 0x8000:
                    continue

            norm = sqrt(norm_squared)
            sample = {
                "sequence": sequence,
                "sample_ms": struct.unpack_from("<I", frame, 8)[0],
                "received_ms": started_ms,
                "quaternion": tuple(value / norm for value in q),
            }
            self._last_sequence = sequence
            self._last_valid_ms = started_ms
            with self._lock:
                self._latest = sample

    def latest(self, now_ms):
        with self._lock:
            sample = self._latest
        if sample is None or not 0 <= now_ms - sample["received_ms"] <= self.timeout_ms:
            return None
        return sample.copy()

